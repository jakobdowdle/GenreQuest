import os
import io
import keras
import numpy as np
import pandas as pd
import functions_framework
from flask import request, jsonify
from pydub import AudioSegment
from process_data import extract_features
import config

# Load the model and normalization data once to improve performance
model = keras.models.load_model(config.model_path)
csv = pd.read_csv(config.csv_path)
allfeatures = csv.iloc[:, 1:len(csv.columns) - 1]
mean = allfeatures.mean()
std = allfeatures.std()

def add_cors_headers(response):
    allowed_origins = ['https://genrequest-b68c1.web.app/', 'http://localhost:5173']
    origin = request.headers.get('Origin')
    if origin in allowed_origins:
        response.headers['Access-Control-Allow-Origin'] = origin
    response.headers['Access-Control-Allow-Methods'] = 'POST, OPTIONS'
    response.headers['Access-Control-Allow-Headers'] = 'Content-Type'
    return response

@functions_framework.http
def predict_genre(request):
    """HTTP Cloud Function for genre prediction based on uploaded .mp3 file.
    Args:
        request (flask.Request): The request object containing an .mp3 file.
    Returns:
        JSON response with genre predictions and CORS headers.
    """
    # Check for file in the request
    if 'file' not in request.files:
        response = jsonify({'error': 'No file part in the request.'})
        response.status_code = 400
        return add_cors_headers(response)

    file = request.files['file']
    
    if file.filename == '':
        response = jsonify({'error': 'No file selected for uploading.'})
        response.status_code = 400
        return add_cors_headers(response)
    
    # Check file extension
    if not file.filename.endswith('.mp3'):
        response = jsonify({'error': 'Invalid file type. Please upload an .mp3 file.'})
        response.status_code = 400
        return add_cors_headers(response)

    try:
        # Convert .mp3 to .wav format in-memory
        audio = AudioSegment.from_file(file, format='mp3')
        wav_io = io.BytesIO()
        audio.export(wav_io, format='wav')
        wav_io.seek(0)

        # Extract features from the .wav file in-memory
        features = extract_features(wav_io)
        features = (features - mean) / std  # Normalize features
        features = np.array(features).reshape(1, -1)  # Reshape for model input

        # Make prediction
        predictions = model.predict(features)
        predictions = np.squeeze(predictions)
        predictions_percentages = [f"{num:.2%}" for num in predictions]

        # Map predictions to genre labels
        genres = os.listdir(config.genre_data_dir)
        genre_predictions = dict(zip(genres, predictions_percentages))
        predicted_genre = genres[np.argmax(predictions)]

        # Create JSON response
        response = jsonify({
            'predictions': genre_predictions,
            'predicted_genre': predicted_genre
        })
        return add_cors_headers(response)

    except Exception as e:
        response = jsonify({'error': f'An error occurred during processing: {str(e)}'})
        response.status_code = 500
        return add_cors_headers(response)
